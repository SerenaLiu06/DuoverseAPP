这是一个问题反馈客户端插件，admin端插件：[https://ext.dcloud.net.cn/plugin?id=4992](https://ext.dcloud.net.cn/plugin?id=4992)
> 参考案例 [uni-starter](https://ext.dcloud.net.cn/plugin?id=5057)