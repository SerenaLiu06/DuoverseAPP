#### uni-id-cf是uni-id-uniCloudFunction的缩写。

#### 直接调用他内置的云函数，即可直接使用uni-id的各类api。

含：登录注册（含用户名密码登录、手机号验证码登录、app一键登录、微信登录、Apple登录、微信小程序登录）、修改密码、忘记密码、退出登录等

> 详细的使用方式见[uni-starter](https://ext.dcloud.net.cn/plugin?id=5057)