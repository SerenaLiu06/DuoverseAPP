<template>
	<view>
		<!-- <view class="example-body">
			<uniNavBar left-icon="arrowleft" right-text="菜单" left-text="返回" title="标题"> </uniNavBar>
		</view> -->
	</view>
</template>

<script>
	// import uniNavBar from '@/components/uni-nav-bar/uni-nav-bar.vue'
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		},
		mounted() { 
			
		},
		components: {
			// uniNavBar
		},
	}
</script>

<style>

</style>
