<template>
	<view>
		
		<unicloud-db ref="udb" where="user_id._id == $cloudEnv_uid" orderby="date" v-slot:default="{data, loading, error, options}" collection="todolist, uni-id-users" field="_id, task, date, user_id._id">
			<view v-if="error">{{error.message}}</view>
			<view v-else>
				<!-- {{data}} -->
				<view v-for="(item,index) in data" v-if="item.date >= todaydate" :key="index" class="itembox">
					<text>
						{{item.date}} 
						{{item.task}}
					</text>
					<button @click="edit_event(item)" type="default">编辑</button>
					<button @click="delete_event(item)" type="default">删除</button>
					
				</view>
			</view>
		</unicloud-db>
		<uni-popup ref="popup" type="dialog">
		    <!-- <uni-popup-message type="info" message="请在未来的日期添加任务"></uni-popup-message> -->
			
			<uni-popup-dialog mode="base" :duration="2000" :before-close="true" @close="close()" @confirm="confirm()">
				
				<uni-forms border>
				    <uni-forms-item label="日期">
				        <uni-datetime-picker type="date" :value="setdate" v-model="setdate" />
				    </uni-forms-item>
				    <uni-forms-item label="内容">
				        <uni-easyinput type="textarea" :value="pretext" v-model="newtext" :inputBorder="true" placeholder="不填写则默认任务无改动" />
				    </uni-forms-item>
				</uni-forms>
			</uni-popup-dialog>
			
		</uni-popup>
	</view>
</template>

<script>
	function getDate(date, AddDayCount = 0) {
		if (!date) {
			date = new Date()
		}
		if (typeof date !== 'object') {
			date = date.replace(/-/g, '/')
		}
		const dd = new Date(date)
	
		dd.setDate(dd.getDate() + AddDayCount) // 获取AddDayCount天后的日期
	
		const y = dd.getFullYear()
		const m = dd.getMonth() + 1 < 10 ? '0' + (dd.getMonth() + 1) : dd.getMonth() + 1 // 获取当前月份的日期，不足10补0
		const d = dd.getDate() < 10 ? '0' + dd.getDate() : dd.getDate() // 获取当前几号，不足10补0
		return {
			fullDate: y + '-' + m + '-' + d,
			year: y,
			month: m,
			date: d,
			day: dd.getDay()
		}
	}
	export default {
		data() {
			return {
				todaydate: getDate(new Date()).fullDate,
				pretext: '',
				newtext: '',
				newid: '',
				setdate: getDate(new Date()).fullDate
			}
		},
		methods: {
			edit_event(item) {
				// this.selected = item
				this.setdate = item.date
				// console.log(this.newtext)
				
				this.pretext = item.task
				this.newtext = item.task
				// console.log(this.pretext, this.newtext)
				this.newid = item._id
				// console.log(this.newtext)
				this.$refs.popup.open('center');
				
				
			},
			confirm() {
				if(this.newtext != '' && this.setdate >= this.todaydate){
					this.$refs.udb.update(this.newid, {
						"task": this.newtext,
						"date": this.setdate,
					})
					this.$refs.popup.close()
					this.$refs.udb.refresh()
				}
				else if(this.newtext == ''){
					uni.showToast({
						title: '任务内容不能为空',
						icon: 'none'
					})
				}
				else if(this.setdate < this.todaydate){
					uni.showToast({
						title: '请在未来的日期添加任务',
						icon: 'none'
					})
				}
			},
			close() {
				this.$refs.popup.close()
			},
			delete_event(item) {
				console.log(item._id)
				this.$refs.udb.remove(item._id)
				
			}
			
		}
	}
</script>

<style lang="scss">
	.itembox {
		display: flex;
		padding: 10px;
	}
</style>
