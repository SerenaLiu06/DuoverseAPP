<template>
	<view>
		<postFab />
		
		
		<!-- <fcircle /> -->
		
	</view>
	
</template>

<script>
	import postFab from "../../components/post-fab/post-fab.vue"
	// import icons from "../../../components/uni-icons/uni-icons.vue"
	// import fcircle from "../../components/friend-circle/friend-circle.vue"
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		},
		components: {
			postFab
			// fcircle
			
		}
	}
</script>

<style>
	
</style>
